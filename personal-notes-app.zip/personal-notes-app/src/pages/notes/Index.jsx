import React from 'react'
import { Link } from 'react-router-dom'

export default function IndexPage() {
  return (
    <p>
      <Link to="/">Home page</Link>
    </p>
  )
}
