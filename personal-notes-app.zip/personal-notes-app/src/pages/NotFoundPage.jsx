import React from 'react'
import NotFoundMessage from '../components/NotFoundMessage'

export default function NotFoundPage() {
  return (
    <section>
      <NotFoundMessage />
    </section>
  )
}
