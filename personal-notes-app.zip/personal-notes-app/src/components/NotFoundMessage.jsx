import React from 'react'

export default function NotFoundMessage() {
  return (
    <>
      <h2>404</h2>
      <p>Page Not Found</p>
    </>
  )
}
